<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/3/16
 * Time: 18:41
 */

namespace App\Tool\Pay;


interface Pay
{
    public function addOrder();
}