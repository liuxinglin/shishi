<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface BakUserRepository.
 *
 * @package namespace App\Repositories;
 */
interface BakUserRepository extends RepositoryInterface
{
    //
}
