<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface BakPermissionRepository.
 *
 * @package namespace App\Repositories;
 */
interface BakPermissionRepository extends RepositoryInterface
{
    //
}
