<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface MemberAddressRepository.
 *
 * @package namespace App\Repositories;
 */
interface MemberAddressRepository extends RepositoryInterface
{
    //
}
