<div class="weui-tabbar">
    <a href="/tryoutProducts/list" class="weui-tabbar__item weui-bar__item_on">
        <span style="display: inline-block;position: relative;">
            <img src="/static/home/images/icon_free_press.png" alt="" class="weui-tabbar__icon">
        </span>
        <p class="weui-tabbar__label" style="color: #FF564C">免费</p>
    </a>
    <a href="/product/index" class="weui-tabbar__item">
        <img src="/static/home/images/icon_shop_normal.png" alt="" class="weui-tabbar__icon">
        <p class="weui-tabbar__label">商城</p>
    </a>

    <a href="/members/index" class="weui-tabbar__item">
        <img src="/static/home/images/icon_player_normal.png" alt="" class="weui-tabbar__icon">
        <p class="weui-tabbar__label">我的</p>
    </a>
</div>