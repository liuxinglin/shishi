<?php $__env->startSection('content'); ?>
    <style>
        .weui-media-box:before {
            border-top: none;
        }
    </style>
    <div class="container" id="container" style="height: 100%;overflow: scroll">
    <div class="swiper-container">
        <div class="swiper-wrapper">
        <div class="swiper-slide"><img src="/static/home/images/banner.png"></div>
        <div class="swiper-slide"><img src="/static/home/images/banner.png"></div>
        <div class="swiper-slide"><img src="/static/home/images/banner.png"></div>
    </div>
        <!-- 如果需要分页器 -->
        <div class="swiper-pagination"></div>
    </div>
    <div class="weui-panel weui-panel_access" style="margin-top: 0px;padding-bottom: 48px">
        <div class="weui-panel__bd">
            <div class="weui-media-box" style="padding: 0px">
                <img src="/static/home/images/product.png" style="width: 100%;height: 100%">
            </div>
            <div class="weui-media-box weui-media-box_text">
                <h4 class="weui-media-box__title" style="white-space: normal;color: #404040">九阳（Joyoung）豆浆机免滤快速制浆米糊1.3L家用全自动</h4>
                <div class="weui-media-box" style="padding: 0px;overflow: hidden">
                    <div class="weui-media-box__hd" style="text-align: left;width: 60%;float: left;">
                        <p>免费试用名额：100</p>
                        <p>已报名：50</p>
                    </div>
                    <div class="weui-media-box__bd" style="width: 40%;float: left;text-align: right">
                        <button style="background: url(/static/home/images/btn_main.png) no-repeat;width:102px; height:34px;background-size:100% 100%;;border: none;color: #ffffff">免费试 ></button>
                    </div>
                </div>
            </div>
        </div>
        <div class="weui-panel__bd">
            <div class="weui-media-box" style="padding: 0px">
                <img src="/static/home/images/product.png" style="width: 100%;height: 100%">
            </div>
            <div class="weui-media-box weui-media-box_text">
                <h4 class="weui-media-box__title" style="white-space: normal;color: #404040">九阳（Joyoung）豆浆机免滤快速制浆米糊1.3L家用全自动</h4>
                <div class="weui-media-box" style="padding: 0px;overflow: hidden">
                    <div class="weui-media-box__hd" style="text-align: left;width: 60%;float: left;">
                        <p>免费试用名额：100</p>
                        <p>已报名：50</p>
                    </div>
                    <div class="weui-media-box__bd" style="width: 40%;float: left;text-align: right">
                        <button style="background: url(/static/home/images/btn_main.png) no-repeat;width:102px; height:34px;background-size:100% 100%;;border: none;color: #ffffff">免费试 ></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('home.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('my-js'); ?>
    <script>
        var mySwiper = new Swiper ('.swiper-container', {
            loop: true,
            autoplay:true,

            // 如果需要分页器
            pagination: {
                el: '.swiper-pagination',
            },
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>