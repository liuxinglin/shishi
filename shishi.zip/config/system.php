<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/4/8
 * Time: 10:18
 */

return [
    'reg_gift' => 200  //注册赠送金币
];